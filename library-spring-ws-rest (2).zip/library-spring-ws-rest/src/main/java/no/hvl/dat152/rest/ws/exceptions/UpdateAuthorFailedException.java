/**
 * 
 */
package no.hvl.dat152.rest.ws.exceptions;

/**
 * 
 */
public class UpdateAuthorFailedException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public UpdateAuthorFailedException(String customMessage) {
		super(customMessage);
	}
	
}
