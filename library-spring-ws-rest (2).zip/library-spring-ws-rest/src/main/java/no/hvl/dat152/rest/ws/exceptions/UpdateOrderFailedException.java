/**
 * 
 */
package no.hvl.dat152.rest.ws.exceptions;

/**
 * 
 */
public class UpdateOrderFailedException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public UpdateOrderFailedException(String customMessage) {
		super(customMessage);
	}
	
}